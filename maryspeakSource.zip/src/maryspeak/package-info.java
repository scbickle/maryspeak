/**
 * This package is Licensed with LGPLv3
 * 
 * Copyright � 2014 Steve Bickle
 * 
 * The maryspeak package provides a command line interface for use with for MaryTTS 
 */
package maryspeak;