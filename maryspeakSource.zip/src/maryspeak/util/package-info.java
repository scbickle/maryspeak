/**
 * This package is Licensed with LGPLv3
 * 
 * Copyright � 2014 Steve Bickle
 * 
 * The maryspeak.util package provides utility classes for maryspeak 
 */
package maryspeak.util;